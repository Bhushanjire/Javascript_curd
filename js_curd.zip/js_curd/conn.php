<?php
    $server_name = 'localhost';
    $user_name = 'root';
    $password = '';
    $dbname = 'studentDB';
    $conn = mysqli_connect($server_name,$user_name,$password,$dbname);
    if(!$conn){
        echo "Database connection error";
    }
?>