<?php
    require('conn.php');
    $query = "SELECT * FROM student";
    $res = mysqli_query($conn,$query);
    if(mysqli_num_rows($res)){
    while($data = mysqli_fetch_assoc($res)){
?>
<tr>
?>
<td><?=$data['name']?></td>
<td><?=$data['mobile_no']?></td>
<td><?=$data['email_id']?></td>
<td>
    <button type="button" onclick="edit_stud('edit',<?=$data['stud_id']?>)">Edit</button>&nbsp;&nbsp;
    <button type="button" onclick="delete_stud('delete',<?=$data['stud_id']?>)">Delete</button>
</td>
<?php
    }
}else{
    echo 0;
}
?>
</tr>