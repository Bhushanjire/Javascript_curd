<?php
require('conn.php');
$reqType = $_REQUEST['reqType'];

switch($reqType){
case 'add_update':
$stude_id = $_POST['stude_id'];
$name = $_POST['name'];
$mobile_no = $_POST['mobile_no'];
$email_id = $_POST['email_id'];

if($stude_id>0){
    $query = "UPDATE student SET name ='".$name."',mobile_no='".$mobile_no."',email_id='".$email_id."' WHERE stud_id='".$stude_id."'";
    $res = mysqli_query($conn,$query);
}else{
    $query = "INSERT INTO student(name,mobile_no,email_id)VALUES('".$name."','".$mobile_no."','".$email_id."')";
$res = mysqli_query($conn,$query);
}
break;

case 'edit':
$stude_id = $_REQUEST['stude_id'];
$query = "SELECT * FROM student WHERE stud_id='".$stude_id."'";
$res = mysqli_query($conn,$query);
$data = mysqli_fetch_assoc($res);
echo json_encode($data);
break;

case 'delete';
$stude_id = $_POST['stude_id'];
$query = "DELETE FROM student WHERE stud_id='".$stude_id."'";
$res = mysqli_query($conn,$query);
if($res){
    echo "success";
}
break;
}
?>