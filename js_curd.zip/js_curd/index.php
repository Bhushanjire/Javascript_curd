<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/comman.css"/>
    <link rel="stylesheet" type="text/css" media="screen" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

    <script src="js/comman.js"></script>
</head>
<body>
<div class='container'>
    <form action="" method='post' id='studFormId'>
        <input type="hidden" name="stude_id" id="stude_id" value="0">
    <fieldset>
<legend>Student</legend>
    <div class='row lineHeight'>
        <div class="col-sm-3">Full Name</div>
        <div class="col-sm-6"><input type="text" name='name' id="name" class='form-control'></div>
    </div>
    <div class='row lineHeight'>
        <div class="col-sm-3">Email ID</div>
        <div class="col-sm-6"><input type="text" name='email_id' id="email_id" class='form-control'></div>
    </div>
    <div class='row lineHeight'>
        <div class="col-sm-3">Mobile No.</div>
        <div class="col-sm-6"><input type="text" name='mobile_no' id="mobile_no" class='form-control'></div>
    </div>

    <div class="row lineHeight">
        <div class='col-sm-6'>
        <button type="button" name="submit" id="submit" class='btn btn-primary' onclick="add_update('add_update')">Add</button>
    </div>
    </fieldset>
    </form>
   

    <table class='table'>
    <tr>
        <th>Name</th>
        <th>Mobile No</th>
        <th>Email ID</th>
        <th>Action</th>
    </tr>
    <tbody id="tbl_rows">
</tbody>
</table>

    </div>
</body>
</html>

