
$(document).ready(function () {
    loadList();
});

function loadList() {
    $.post("list.php", function (data, status) {
        $('#tbl_rows').html(data);
    });
}

function add_update(reqType) {
    var formData = $('#studFormId').serialize();
    $.post("opp.php?reqType=" + reqType, formData, function (data, status) {
        loadList();
    });
}

function edit_stud(reqType, stude_id) {
    var formData = {
        reqType: reqType,
        stude_id: stude_id
    }

    $.post("opp.php", formData, function (data, status) {
        var studData = JSON.parse(data);
        $('#stud_id').val(studData['stud_id']);
        $('#name').val(studData['name']);
        $('#mobile_no').val(studData['mobile_no']);
        $('#email_id').val(studData['email_id']);
    });
}
function delete_stud(reqType, stude_id) {
    var formData = {
        reqType: reqType,
        stude_id: stude_id
    }
    $.post("opp.php", formData, function (data, status) {
        loadList();
    });
}

